export const LOG_IN ="LOG_IN"
export const OwenerLOG_IN_REQUES ="LOG_IOwenerLOG_IN_REQUESN_REQUES"
export const OwenerLOG_IN_FIALUER ="OwenerLOG_IN_FIALUER"
export const OwenerLOG_IN_SUCCSESS ="OwenerLOG_IN_SUCCSESS"
