import React ,{useState} from 'react'
import AddHotel from "./component/AddHotel";
import AddNewAdmin from "./component/AddNewAdmin";
import LoginPage from "./component/LogInPage";
import MainPageAdmin from "./component/MainPageAdmin";
import {BrowserRouter as Router ,Switch,Route,Redirect} from 'react-router-dom'
import hotels from './hotels.json'
import HotelPage from './component/HotelPage';
import RoomEdit from './component/RoomEdit';
import HotelEdit from './component/HotelEdit';
import FeaturesEdit from './component/FeaturesEdit';
import Users from './component/Users';
export const hotelsContext=React.createContext()

function App() {
  
  const [token,setToken]=useState('')
  const [myhotels ,setHotels]=useState([...hotels]) 
  console.log(token)
  
  return (
    <div className="App">

        <Router>
          <Switch>
         
          <Route path='/' exact > {token? <Redirect to='/mainPageAdmin'/>:
          <Route path='/' exact  render={()=><LoginPage setToken={setToken}/>} />}</Route>
          <Route path='/' exact render={()=><LoginPage setToken={setToken}/>} />
          <Route path='/mainPageAdmin'  exact render={()=><MainPageAdmin setHotels={setHotels} myhotels={myhotels} />}/>
          <Route path='/mainPageAdmin/addNewAdmin' exact render={()=><AddNewAdmin token={token}/>} />
          <Route path='/mainPageAdmin/addHotel' exact render={()=><AddHotel token={token}/>} />
          <Route path='/hotelPage/hotelEdit' exact render={()=><HotelEdit token={token}/>} />
          <Route path='/hotelPage/featuresEdit' exact render={()=><FeaturesEdit token={token} />}/>
          <Route path='/hotelPage/roomEdit/:id' exact component={RoomEdit}/>
        <Route path='/hotelPage/Users' exact component={Users}></Route>
          <Route path='/hotelPage/:id' exact component={HotelPage}/>
         
          </Switch>
          </Router>
         
    </div>

  );
}

export default App;
