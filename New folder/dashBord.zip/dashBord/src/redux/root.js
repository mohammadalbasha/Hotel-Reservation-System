// import hotelsReducer from './hotels/hotelsReducer'
// import {combineReducers } from 'redux'
// const root = combineReducers({
//     hotels:hotelsReducer
// })
// export default root