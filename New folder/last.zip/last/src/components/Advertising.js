import React from 'react'

function Advertising() {
    return (
        <div className='Advertising'>
            <img style={{maxWidth:'100%',height:"auto"}} src='./imgs/Advertising.jpg'></img>
        </div>
    )
}

export default Advertising
