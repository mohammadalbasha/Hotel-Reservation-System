import React ,{useState,useEffect} from 'react'
import users from '../users.json'
import axios from 'axios'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons'
import Navbar from './Navbar'
function Users() {
    const [myUsers,seUsers]=useState([...users])
    

useEffect(() => { 
    axios.get("http://localhost:8080/admin/getUsers")
    .then(res=>{seUsers(res)})
    .catch(error=>{console.log(error)})

}, [])
  
    return (
        <div className='usersPage'>
            <Navbar/>
             <div className='innerUsers'>
                <h1 className='usersHeader'>Users :</h1>
                <div className='users'>
                    { myUsers.map(user=><div className={`user border-${Math.floor(Math.random() * 5)+1}`}>
                        <div className='userInfo'>
                         <div>{user.name}</div>
                            <div>phoneNumber :{user.phoneNumber}</div>
                            <div>email :{user.email}</div>
                            <div type='button' className='block'>block</div>
                            
                        </div>
                     
                      
                         <table className='orders'>
                         <tr>
                         <th>room number</th>
                         <th>price</th>
                         <th>chick in</th>
                         <th>chick out</th>
                         <th>hotel name</th>
                         <th>country</th>
                         </tr>
                         {user.orders.map(order=> <tr>
                          <td>{order.room.number}</td>
                          <td>{order.room.price}</td>
                          <td>{order.checkIn }</td>
                          <td>{order.checkOut }</td>
                          <td>{order.hotel.name }</td>
                          <td>{order.hotel.country }</td>
                          </tr> )
                           }
                          </table>
                        
                            
        
                    </div>)
                    }
                </div>
            </div>
        </div>
    )
}

export default Users
