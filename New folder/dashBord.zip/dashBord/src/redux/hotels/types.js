export const FATCH_HOTELS_RECUEST='FATCH_HOTELS_RECUEST'
export const FATCH_HOTELS_succsess='FATCH_HOTELS_succsess'
export const FATCH_HOTELS_error='FATCH_HOTELS_error'
export const FATCH_HOTELS='FATCH_HOTELS'