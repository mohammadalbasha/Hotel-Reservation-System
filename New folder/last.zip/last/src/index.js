import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import CV from './CV';

ReactDOM.render(
    <App/>,
  document.getElementById('root')
);
