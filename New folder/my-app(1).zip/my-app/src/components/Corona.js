import React from 'react'

function Corona() {
    return (
     
        <div className='corona '>
             <h5>Restrictions related to your trip</h5>
            COVID-19 alert: Travel requirements are changing rapidly, including need for pre-travel COVID-19 testing and quarantine on arrival. Check restrictions for your trip.
        </div>
      
    )
}

export default Corona
