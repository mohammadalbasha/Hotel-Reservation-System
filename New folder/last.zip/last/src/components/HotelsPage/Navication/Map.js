import { Button } from '@material-ui/core'
import React from 'react'

function Map() {
    return (
        <div className='map filter'>
            <Button variant="contained" color="secondary">
                Map View
                </Button>
        </div>
    )
}

export default Map
