import React ,{useEffect, useState}from 'react'
import myNotes from '../../myNotes.json'
import axios from 'axios'

function Reviews() {
    const [notes,setNotes]=useState(myNotes)
 
    useEffect(() => {
        window.scroll(0,0)
        axios.get('notesUrl')
        .then(notes=>{
            setNotes(notes)
        })
        .catch(error=>{
     
        })
    }, [])
    return (
        <div className='reviews'style={{position:"relative",color:"#fff" , margin:"20px 100px"}}>
            <h4>Reviews :</h4>
           {notes.map(note=><div  style={{margin:"20px 0",borderBottom:"1px solid"}}>
            <p className='notes'><span  className='evaluating'>{note.evaluating}</span><span >{note.notes}</span></p>
            <p><span style={{fontWeight:"bold", marginLeft:"30px" ,marginRight:"5px"}}>Suggestions:</span>{note.suggestions}</p>
           </div>)}
        </div>
    )
}

export default Reviews
